/*
@license

dhtmlxGantt v.4.0.0 Stardard
This software is covered by GPL license. You also can obtain Commercial or Enterprise license to use it in non-GPL project - please contact sales@dhtmlx.com. Usage without proper license is prohibited.

(c) Dinamenta, UAB.
*/


Useful links
-------------

- Online  documentation
	http://docs.dhtmlx.com/gantt/

- Downloadable documentation
	CHM version
		http://dhtmlx.com/x/download/regular/dhtmlxgantt_chm.zip
	HTML version
		http://dhtmlx.com/x/download/regular/dhtmlxgantt_docs_html.zip
	
- Support forum
	http://forum.dhtmlx.com/viewforum.php?f=15